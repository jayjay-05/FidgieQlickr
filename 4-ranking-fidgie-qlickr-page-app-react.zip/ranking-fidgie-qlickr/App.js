import React from 'react';
import { Text, TextInput, ScrollView, Image, SafeAreaView, StyleSheet } from 'react-native';
import Constants from 'expo-constants';


export default function fidgieQlickApp(){


  return (
    <ScrollView style={styles.container}>
    <Text></Text>
    <Text></Text>
    <Text style={styles.paragraph}>Please rank which feature of the Fidgie Qlickr you are most likely to use. 
(1 for most frequent, 4 for least frequent)  </Text>
<Text></Text>

    <Image
        source={{uri: "https://scontent.xx.fbcdn.net/v/t1.15752-9/292266646_1255595508577578_1615600273637715784_n.png?stp=dst-png_p180x540&_nc_cat=111&ccb=1-7&_nc_sid=aee45a&_nc_ohc=g269LfzbzbwAX_JY-xw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_AVJzcxc-D3BAbpO9MDcs5PfGEvt3eitAKpH1kkmZlTjUDg&oe=633134FA"}}
        style={{width: 345, height: 590}}
      />
    <TextInput
        style={{
          height: 35,
          borderColor: 'gray',
          backgroundColor: '#ff6347',
          borderWidth: 1
        }}
        defaultValue=" Big Clicker: "
      />

      <TextInput
        style={{
          height: 35,
          borderColor: 'gray',
          backgroundColor: '#a9a9a9',
          borderWidth: 1
        }}
        defaultValue=" Slider: "
      />

      <TextInput
        style={{
          height: 35,
          borderColor: 'gray',
           backgroundColor: '#ff6347',
          borderWidth: 1
        }}
        defaultValue=" Joystick: "
      />

      <TextInput
        style={{
          height: 35,
          borderColor: 'gray',
          backgroundColor: '#dda0dd',
          borderWidth: 1
        }}
        defaultValue=" Buttons: "
      />
      </ScrollView>
  );
}





const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 5,
  },
  paragraph: {
    margin: 35,
    fontSize: 15,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});


