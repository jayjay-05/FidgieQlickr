import React, { useState } from "react";
import { Button, Text, View, Image, StyleSheet} from "react-native";
import Constants from 'expo-constants';

const Feeling = (props) => {
  const [isFeeling, setIsFeeling] = useState(true);

  return (
    <View style={styles.container}>

    <Text> </Text>

     <Text>Optional: Please declare if you are affected by: </Text>
      <Text>
        {props.name}{isFeeling ? "" : " and I am comfortable with sharing!"}
      </Text>
      <Button
      color="#7d84b2"
        onPress={() => {
          setIsFeeling(false);
        }}
        disabled={!isFeeling}
        title={isFeeling ? "I do experience this!" : "Thank you for the response!"}
      />
    </View>
  );
}

const App = () => {
  return (
    <>
      <Feeling name="ADHD" />
      <Feeling name="ADD" />
      <Feeling name="Anxiety" />
    </>
  );
}

export default App;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#c4f4fd',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
