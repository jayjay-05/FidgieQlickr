import React from 'react';
import { StyleSheet, Button, View, SafeAreaView, Text, Alert, TextInput } from 'react-native';

const Separator = () => (
  <View style={styles.separator} />
);

const App = () => (
  <SafeAreaView style={styles.container}>
    <View>
      <Text style={styles.title}>
        Please select your reasons for using the Fidgie Qlickr .
      </Text>
      <Button
        title="Calm Nerves"
        color = "#7d84b2"
        onPress={() => Alert.alert('Response Received')}
      />
    </View>
    <Separator />
    <View>
      <Button
        title="Relieve Stress"
        color = "#7d84b2"
        onPress={() => Alert.alert('Response Received')}
      />
    </View>
    <Separator />
    <View>
      <Button
        title="Help With Focus"
        color = "#7d84b2"
        onPress={() => Alert.alert('Response Received')}
      />
    </View>
    <Separator />
    <View>
      <Button
        title="Keep Kalm and karry on"
        color = "#7d84b2"
        
        onPress={() => Alert.alert('Response Received')}
      />
    </View>
     <Separator />
    <View>
      <TextInput
        style={{
          height: 35,
          borderColor: 'gray',
          backgroundColor: '#7d84b2',
          color : 'white',
          borderWidth: 1
        }}
        defaultValue=" Enter Any Other Reason: "
      />
      
    </View>

  </SafeAreaView>
);

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fde85d',
    flex: 1,
    justifyContent: 'center',
    marginHorizontal: 16,
  },
  title: {
    textAlign: 'center',
    marginVertical: 8,
  },
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  separator: {
    marginVertical: 8,
    borderBottomColor: '#737373',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
});

export default App;
