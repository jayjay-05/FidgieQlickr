import React from 'react';
import { Text, TextInput, ScrollView, Image, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

const fidgieQlickApp = () => {

  return (
    <ScrollView style={styles.container}>
    <Image
        source={{uri: "https://scontent.xx.fbcdn.net/v/t1.15752-9/299217304_311845934482429_3543354581861281085_n.png?stp=dst-png_p403x403&_nc_cat=111&ccb=1-7&_nc_sid=aee45a&_nc_ohc=SbU1Pl5BBUQAX-sQ9_D&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_AVLcQUWhvfBWVx0EMx_Ha35kGzM2Y8efbN6qdHRApvemVg&oe=633170F9"}}
        style={{width: 335, height: 265}}
      />
      <Text style={styles.paragraph}> Hello, this is Fidgie Qlickr! Your personal toy and app to help track your emotions </Text>
    
      <TextInput
        style={{
          height: 50,
          borderColor: 'gray',
          backgroundColor: '#fde85d',
          borderWidth: 1
        }}
        defaultValue="Enter Your Name: "
      />
        <Text> </Text>
        <TextInput
        style={{
          height: 50,
          borderColor: 'gray',
          backgroundColor: '#fde85d',
          borderWidth: 1
        }}
        defaultValue="Enter Your Age: "
      />
<Text>  </Text>
      <Text style={styles.paragraph}> On a scale of 1 to 10, rate your stress levels, 1 being not at all and 
      10 being extremely stressed. </Text>

       <TextInput
        style={{
          height: 50,
          borderColor: 'gray',
          backgroundColor: '#fde85d',
          borderWidth: 1
        }}
        defaultValue="Enter Your Average Stress Levels: "
      />



  </ScrollView>
  );
}

export default fidgieQlickApp;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#c4f4fd',
    padding: 8,
  },
  paragraph: {
    margin: 35,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
