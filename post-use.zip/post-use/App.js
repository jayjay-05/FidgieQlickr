
import { Text, ScrollView, StyleSheet, TextInput } from 'react-native';
import Constants from 'expo-constants';


export default function PostUseApp() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.paragraph}>
        Thank you for using Fidgie Qlickr. Please fill out this post use survey for data analysis. 
      </Text>
      <Text>  </Text>
      <Text> On a scale of 1 to 10, rate your stress levels, 1 being not at all and 
      10 being extremely stressed. </Text>
<Text> </Text>
       <TextInput
        style={{
          height: 50,
          borderColor: 'gray',
          backgroundColor: '#7d84b2',
          borderWidth: 1
        }}
        defaultValue="Enter Your Average Stress Levels: "
      />
      <Text>  </Text>
      <Text> In your opinion was Fidgi Qlickr useful to you in any way? </Text>
<Text> </Text>
       <TextInput
        style={{
          height: 50,
          borderColor: 'gray',
          backgroundColor: '#7d84b2',
          borderWidth: 1
        }}
        defaultValue="Enter Your Response: "
      />

      <Text>  </Text>
      <Text> Please rerank the features of the Fidgi Qlickr as you see fit. (1 for most frequent use and 4 for least frequent use) </Text>
<Text> </Text>
       <TextInput
        style={{
          height: 35,
          borderColor: 'gray',
          backgroundColor: '#7d84b2',
          borderWidth: 1
        }}
        defaultValue=" Big Clicker: "
      />

      <TextInput
        style={{
          height: 35,
          borderColor: 'gray',
          backgroundColor: '#7d84b2',
          borderWidth: 1
        }}
        defaultValue=" Slider: "
      />

      <TextInput
        style={{
          height: 35,
          borderColor: 'gray',
          backgroundColor: '#7d84b2',
          borderWidth: 1
        }}
        defaultValue=" Joystick: "
      />

      <TextInput
        style={{
          height: 35,
          borderColor: 'gray',
          backgroundColor: '#7d84b2',
          borderWidth: 1
        }}
        defaultValue=" Buttons: "
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#e0e0e0',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
